package com.rabobank.payment.util;

/**
 * Transaction status
 */
public enum TransactionStatus
{
    Accepted, Rejected; // NOSONAR
}
