package com.rabobank.payment.repository;

import org.springframework.stereotype.Component;

@Component
public class PaymentInitiationRepositoryImpl implements PaymentInitiationRepository
{

}
