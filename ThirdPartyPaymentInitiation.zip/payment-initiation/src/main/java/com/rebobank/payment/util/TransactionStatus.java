package com.rebobank.payment.util;

/**
 * Transaction status
 */
public enum TransactionStatus
{
    Accepted, Rejected; // NOSONAR
}
